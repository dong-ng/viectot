# Security Policy

## Reporting a Vulnerability

Please report security issues to:
    
* Chris Boden [cboden@gmail.com](cboden@gmail.com)
* Matt Bonneau [matt@bonneau.net](matt@bonneau.net)
